module.exports = {
  HOST: "localhost",
  USER: "litg2498_root",
  PASSWORD: "xL98O~a4^glG",
  DB: "litg2498_db",
  dialect: "mysql",
};
